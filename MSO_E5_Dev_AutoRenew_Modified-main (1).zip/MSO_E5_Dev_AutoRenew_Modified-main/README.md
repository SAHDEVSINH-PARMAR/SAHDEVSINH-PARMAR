# MSO_E5_Dev_AutoRenew_Modified
This is a python program based on Git Actions modified to automatically generate development actions via Microsoft Graph API like a real developer in order to active Microsoft Office 365 E5 Developer Trail subscription auto renew.

# Notice
This repo may lead to unknown issues, problems, information leaks, etc. 

Use at your own risk.

The author DO NOT provide help or further assistance for personal reasons.

Please DO NOT open issues or PR over this project, I do not have enough time to respond due to personal reasons, thanks for understanding.
